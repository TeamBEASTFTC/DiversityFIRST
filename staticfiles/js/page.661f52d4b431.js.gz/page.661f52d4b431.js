
$(function(){
  img_h_dimension = (($(window).height()) * 0.9);
  $('.team_photo').height(img_h_dimension);
});


/*
var marker = document.getElementById("marker");
var welEl = document.getElementById("Welcome_Mission");
var top_d_wel = welEl.offsetTop;

var nav = document.getElementById("navBar");
var op = 0;
var eye = 0;

// fade out

function fadeOut(el){
  el.style.opacity = 1;

  (function fade() {
    if ((el.style.opacity -= .1) < 0) {
      el.style.display = "none";
    } else {
      requestAnimationFrame(fade);
    }
  })();
}

// fade in

function fadeIn(el, display){
  el.style.opacity = 0;
  el.style.display = display || "block";

  (function fade() {
    var val = parseFloat(el.style.opacity);
    if (!((val += .03) > 1)) {
      el.style.opacity = val;
      requestAnimationFrame(fade);
    }
  })();
}

window.onscroll = function (e) {
  if ((window.scrollY >= (top_d_wel - 50)) && (eye == 0)){
    fadeIn(nav);
    eye += 1;

  }
  */
  /*
  if (window.scrollY < (top_d_wel - 50)) {
    fadeOut(nav);
    eye = 0;
   }
}
*/


 
